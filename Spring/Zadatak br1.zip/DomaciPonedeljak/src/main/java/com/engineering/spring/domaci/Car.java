package com.engineering.spring.domaci;

public class Car {
	
	private String fuel;
	private int power;
	private String brand;
	
	
	public Car() {
		
		this.fuel="Diesel";
		this.power=3500;
		this.brand="Opel";
		
	}


	@Override
	public String toString() {
		return "Car [fuel=" + fuel + ", power=" + power + ", brand=" + brand + "]";
	}
	
	
	
	
	
	
	

}
