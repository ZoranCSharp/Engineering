package com.engineering.spring.domaci;

public class Person {

	private String name;
	private String lastName;
	private String  address;
	
	
	
	
	public Person() {
		
		this.name="Petar";
		this.lastName="Petrovic";
		this.address="Bez broja 1";
	}




	@Override
	public String toString() {
		return "Person [name=" + name + ", lastName=" + lastName + ", address=" + address + "]";
	}
	
	
	
	
	
	
}
