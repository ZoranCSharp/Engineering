package model;


import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
@PrimaryKeyJoinColumn(referencedColumnName="StudentID")
@Entity(name="Samofinansirajuci")

public class Samofinansirajuci extends Student{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer ids;
	private String semail;
	private String name;
	private String surname;
	
	
	public Samofinansirajuci() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Samofinansirajuci(Integer id, String firstName, String lastName, String email) {
		super(id, firstName, lastName, email);
		// TODO Auto-generated constructor stub
	}


	public Integer getIds() {
		return ids;
	}
	public void setIds(Integer ids) {
		this.ids = ids;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	@Override
	public String toString() {
		return "Samofinansirajuci [ids=" + ids + ", semail=" + semail + ", name=" + name + ", surname=" + surname + "]";
	}
	
	
	
}
