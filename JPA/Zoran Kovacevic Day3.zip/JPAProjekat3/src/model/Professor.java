package model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="PROFESSOR")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type")
public class Professor implements Serializable {
		
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ProfessorID")
	private Integer id;
	private String firstName;
	private String lastName;
	private String  title;
	
	@OneToMany(mappedBy = "professor")
	private List<Mentoring> mentorings;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name ="DepartmentID")
	private Department Department;
	
	
	
	
	public Professor(Integer id, String firstName, String lastName, String title, List<Mentoring> mentorings,
			model.Department department) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.title = title;
		this.mentorings = mentorings;
		Department = department;
	}
	
	
	public Professor() {
		super();
		// TODO Auto-generated constructor stub
	}


	public List<Mentoring> getMentorings() {
		return mentorings;
	}
	public void setMentorings(List<Mentoring> mentorings) {
		this.mentorings = mentorings;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "Professor [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", title=" + title + "]";
	}
	
	

}
