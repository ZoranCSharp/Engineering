package model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Glavna {

	public static void main(String args[]) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employeeDb");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		/*
		 * Department dep = new Department(); dep.setName("Softversko inzenjerstvo");
		 * em.persist(dep);
		 * 
		 * Student student = new Student(); student.setFirstName("Petar");
		 * student.setLastName("Petrovic"); student.setEmail("pettar154@gmail.com");
		 * em.persist(student);
		 */

		Professor prof = new Vanredan();
		prof.setFirstName("Petar");
		prof.setLastName("Prezime");
		prof.setTitle("Dr.");
		em.persist(prof);
		
		
		Student stud = new Samofinansirajuci();
		stud.setFirstName("Ime2");
		stud.setLastName("Prezim2");
		stud.setEmail("ime@g.mail");
		em.persist(stud);
		

		tx.commit();		
		em.close();
	}
}
