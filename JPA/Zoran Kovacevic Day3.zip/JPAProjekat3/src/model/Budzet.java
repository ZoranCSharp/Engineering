package model;



import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;



@Entity(name="Budzet")
@PrimaryKeyJoinColumn(referencedColumnName="StudentID")
public class Budzet extends Student{
	
	
	private static final long serialVersionUID = 1L;

	private Integer idb;
	
	private String bName;
	private String bSurname;
	
	private String bemail;
	
	
	
	
	
	public Budzet(Integer idb, String bName, String bSurname, String bemail) {
		super();
		this.idb = idb;
		this.bName = bName;
		this.bSurname = bSurname;
		this.bemail = bemail;
	}

	
	



	public Budzet() {
		super();
		// TODO Auto-generated constructor stub
	}






	public Integer getIdb() {
		return idb;
	}




	public void setIdb(Integer idb) {
		this.idb = idb;
	}




	public String getbName() {
		return bName;
	}




	public void setbName(String bName) {
		this.bName = bName;
	}




	public String getbSurname() {
		return bSurname;
	}




	public void setbSurname(String bSurname) {
		this.bSurname = bSurname;
	}




	public String getBemail() {
		return bemail;
	}




	public void setBemail(String bemail) {
		this.bemail = bemail;
	}




	@Override
	public String toString() {
		return "Budzet [idb=" + idb + ", bName=" + bName + ", bSurname=" + bSurname + ", email=" + bemail + "]";
	}

	
	

	
	
	
	
}
