package model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Glavna {

	public static void main(String args[]) {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("employeeDb");
	EntityManager em = emf.createEntityManager();
	EntityTransaction tx = em.getTransaction();
	tx.begin();
	
	Department dep = new Department();
	dep.setName("Softversko inzenjerstvo");
	
	Student student = new Student();
	student.setFirstName("Petar");
	student.setLastName("Petrovic");
	student.setEmail("pettar154@gmail.com");
		
	
	
	em.persist(dep);
	em.persist(student);
	tx.commit();
	em.close();
	}
}
