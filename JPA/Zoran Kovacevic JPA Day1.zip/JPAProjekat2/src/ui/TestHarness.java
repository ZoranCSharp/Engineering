package ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import model.Employee;

public class TestHarness {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("employeeDb");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		Employee employee2 = new Employee();
		employee2.setFirstName("Ana");

		em.persist(employee2);
		tx.commit(); // without commit changes are not going to reach the database!
		em.close(); // closes entityManager in order to realase any resource
	}

}